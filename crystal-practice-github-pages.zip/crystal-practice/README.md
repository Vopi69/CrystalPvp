# Crystal Practice

Statická webovka pro GitHub Pages s Anchor Practice a Crystal Speed.

## Nasazení
1. Nahraj `index.html` do kořene GitHub repozitáře.
2. Otevři **Settings → Pages**.
3. Zvol **Deploy from a branch**, větev `main`, složku `/(root)` a ulož.

## Poznámky
- Jde o samostatnou webovou simulaci, neovládá skutečný Minecraft klient.
- Bindy, nastavení a lokální rekordy se ukládají v `localStorage` prohlížeče.
- Globální leaderboard vyžaduje externí databázi a serverovou validaci.
- Textury se načítají z veřejného repozitáře minecraft-assets; pro úplně nezávislé hostování je lze přidat lokálně do repozitáře.
